The package provide the implementation of partition of unity method. 


For usage example see at: https://github.com/sandro-lancellotti/PU


For detail about implementation see R. Cavoretto, A. De Rossi, E. Perracchione, S. Lancellotti, 
Software Implementation of the Partition of Unity Method, preprint
\
\
Cite as R. Cavoretto, A. De Rossi, E. Perracchione, S. Lancellotti, 
Software Implementation of the Partition of Unity Method, preprint


